# TokeBot

A chat bot designed for use in [ChronicChat](http://chronicchat.cc).

Manages toke sessions for users so they can toke together.

# Requirements

Node.js

Discord.js

MongoDB

dotenv

# Environment Variables

**discord** - Discord bot key

**mongo** - MongoDB password
